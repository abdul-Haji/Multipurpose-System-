<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\BackupController;
use App\Http\Controllers\BankAccountController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\CompanyGoodController;
use App\Http\Controllers\CompanyReportController;
use App\Http\Controllers\ContactControlle;
use App\Http\Controllers\CreditAndDebetController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DailyExpenseController;
use App\Http\Controllers\DailyReportController;
use App\Http\Controllers\DailyTaskController;
use App\Http\Controllers\DailyTransactionController;
use App\Http\Controllers\EstateController;
use App\Http\Controllers\InvestorController;
use App\Http\Controllers\MyPasswordController;
use App\Http\Controllers\OfficeWarehouseExpenseController;
use App\Http\Controllers\PersonalGoodController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductionCapacityController;
use App\Http\Controllers\ProductSaleController;
use App\Http\Controllers\PurchasedRawMaterialController;
use App\Http\Controllers\StuffController;
use App\Http\Controllers\StuffAttendanceController;
use App\Http\Controllers\StuffPaymentSalaryController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VisaRegistrationController;
use Illuminate\Support\Facades\Route;



Route::post('login', [AuthController::class, 'login']);
Route::middleware('auth:sanctum')->group(function () {
    Route::post('logout', [AuthController::class, 'logout']);

    Route::apiResource('users', UserController::class);
    Route::get('customers/list', [CustomerController::class, 'customersList']);
    Route::get('products/list', [ProductController::class, 'productsList']);
    Route::apiResource('products', ProductController::class);
    Route::apiResource('customers', CustomerController::class);
    Route::get('suffs/list', [StuffController::class, 'suffsList']);
    Route::apiResource('stuffs', StuffController::class);
    Route::get('stuff-attendances/absent-report', [StuffAttendanceController::class, 'absentReport']);
    Route::post('stuff-attendances/bulk', [StuffAttendanceController::class, 'bulkStore']);
    Route::apiResource('stuff-attendances', StuffAttendanceController::class);
    Route::apiResource('product-sales', ProductSaleController::class);
    Route::get('raw-materials/list', [PurchasedRawMaterialController::class, 'rawMaterialsList']);
    Route::post('raw-materials/pick', [PurchasedRawMaterialController::class, 'pick']);
    Route::apiResource('raw-materials', PurchasedRawMaterialController::class);
    Route::apiResource('office-warehouse-expense', OfficeWarehouseExpenseController::class);
    Route::apiResource('daily-expense', DailyExpenseController::class);
    Route::apiResource('company-goods', CompanyGoodController::class);
    Route::post('bank-accounts/transactions', [BankAccountController::class, 'transactions']);
    Route::apiResource('bank-accounts', BankAccountController::class);
    Route::apiResource('personal-goods', PersonalGoodController::class);
    Route::apiResource('my-passwords', MyPasswordController::class);
    Route::apiResource('daily-tasks', DailyTaskController::class);
    Route::apiResource('contacts', ContactControlle::class);
    Route::apiResource('investors', InvestorController::class);
    Route::apiResource('production-capacities', ProductionCapacityController::class);
    Route::apiResource('daily-transactions', DailyTransactionController::class);
    Route::apiResource('estates', EstateController::class);
    Route::apiResource('stuff-payment-salaries', StuffPaymentSalaryController::class);
    Route::apiResource('company-reports', CompanyReportController::class);
    Route::get('companies/list', [CompanyController::class, 'companyList']);
    Route::apiResource('companies', CompanyController::class);
    Route::get('daily-reports/list', [DailyReportController::class, 'dailyReportList']);
    Route::get('daily-reports', [DailyReportController::class, 'dailyReport']);
    Route::post('visa-registrations/change-status', [VisaRegistrationController::class, 'changeStatus']);
    Route::apiResource('visa-registrations', VisaRegistrationController::class);
    Route::post('credits-and-debets/change-status', [CreditAndDebetController::class, 'changeStatus']);
    Route::post('credits-and-debets/adjust', [CreditAndDebetController::class, 'adjust']);
    Route::apiResource('credits-and-debets', CreditAndDebetController::class);
    Route::get('backup', [BackupController::class, 'backup']);
    Route::post('restore', [BackupController::class, 'restore']);
    });
