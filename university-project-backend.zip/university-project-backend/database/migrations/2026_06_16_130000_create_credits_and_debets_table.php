<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('credits_and_debets', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('father_name');
            $table->string('phone_number');
            $table->text('address');
            $table->enum('status', ['new', 'in_progress', 'done'])->default('new');
            $table->enum('transaction_type', ['paid', 'recieved']);
            $table->decimal('amount', 12, 2)->nullable();
            $table->string('currency')->nullable();
            $table->text('description')->nullable();
            $table->string('payment_reason')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('credits_and_debets');
    }
};
