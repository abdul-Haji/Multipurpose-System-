<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('head_name');
            $table->string('head_last_name');
            $table->string('head_phone_number');
            $table->string('assistant_name');
            $table->string('assistant_last_name');
            $table->string('assistant_phone_number');
            $table->string('permission_produced_date');
            $table->string('permission_expired_date');
            $table->string('permission_produced_place');
            $table->string('permission_produced_company');
            $table->text('description')->nullable();
            $table->string('paid_amount');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('companies');
    }
};
