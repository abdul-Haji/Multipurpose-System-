<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stuff_attendances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('stuff_id')->constrained('stuffs')->cascadeOnDelete();
            $table->date('date');
            $table->enum('status', ['present', 'absent', 'leave', 'late'])->default('present');
            $table->text('description')->nullable();
            $table->timestamps();

            // a staff member can only have one attendance record per day
            $table->unique(['stuff_id', 'date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stuff_attendances');
    }
};
