<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_sales', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->nullable()->constrained('customers')->cascadeOnUpdate()->nullOnDelete();
            $table->foreignId('product_id')->nullable()->constrained('products')->cascadeOnUpdate()->nullOnDelete();
            $table->integer('quantity');
            $table->enum('unit', ['کیلوگرم', 'لیتر', 'متر', 'تن', 'بسته', 'عدد']);
            $table->string('currency');
            $table->integer('price_per_unit');
            $table->string('date');
            $table->string('shop_name');
            $table->integer('price_in_afg')->nullable();
            $table->integer('currency_price_in_afg')->nullable();
            $table->text('description')->nullable();
            $table->integer('paid_amount');
            $table->integer('remaining_amount');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_sales');
    }
};
