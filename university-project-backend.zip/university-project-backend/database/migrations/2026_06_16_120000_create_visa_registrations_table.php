<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('visa_registrations', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('last_name')->nullable();
            $table->string('passport_number')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('city')->nullable();
            $table->text('afg_full_address')->nullable();
            $table->text('abroad_full_address')->nullable();
            $table->string('currency')->nullable();
            $table->decimal('visa_price', 12, 2)->nullable();
            $table->decimal('airplane_ticket_price', 12, 2)->nullable();
            $table->decimal('paid_amount', 12, 2)->nullable();
            $table->decimal('remaining_amount', 12, 2)->nullable();
            $table->enum('visa_type', ['کاری', 'سیاحتی', 'زیارتی', 'درمانی'])->nullable();
            $table->enum('travel_mode', ['land', 'air'])->nullable();
            $table->enum('visa_done_status', ['new', 'in_progress', 'done', 'cancelled'])->default('new');
            $table->string('visa_period')->nullable();
            $table->string('introducer')->nullable();
            $table->string('introducer_phone_number')->nullable();
            $table->date('visa_taken_date')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('visa_registrations');
    }
};
