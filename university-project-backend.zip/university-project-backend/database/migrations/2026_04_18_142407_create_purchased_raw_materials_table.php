<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('purchased_raw_materials', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->integer('quantity');
            $table->enum('unit', ['کیلوگرم', 'لیتر', 'متر', 'تن', 'بسته', 'عدد']);
            $table->integer('price_per_unit');
            $table->string('currency');
            $table->string('date');
            $table->text('description')->nullable();
            $table->string('bill_number');
            $table->string('buyer_name');
            $table->string('sealer_name');
            $table->string('sealer_phone_number');
            $table->string('company_name');
            $table->integer('price_in_afg')->nullable();
            $table->integer('currency_price_in_afg')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('purchased_raw_materials');
    }
};
