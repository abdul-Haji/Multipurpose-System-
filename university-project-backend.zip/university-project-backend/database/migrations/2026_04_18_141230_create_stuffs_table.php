<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stuffs', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('father_name');
            $table->string('last_name');
            $table->string('phone_number');
            $table->string('contract_type');
            $table->string('contract_start_date');
            $table->string('contract_end_date');
            $table->integer('salary');
            $table->string('currency');
            $table->string('profile')->nullable();
            $table->string('responsiblity');
            $table->string('identity_card_number');
            $table->string('full_address');
            $table->string('guarantee');
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stuffs');
    }
};
