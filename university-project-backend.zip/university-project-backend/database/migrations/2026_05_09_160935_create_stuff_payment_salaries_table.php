<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stuff_payment_salaries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('stuff_id')->constrained('stuffs')->onDelete('cascade')->onUpdate('cascade');
            $table->integer('paid_amount');
            $table->integer('remaining_amount')->nullable();
            $table->string('paid_date');
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stuff_payment_salaries');
    }
};
