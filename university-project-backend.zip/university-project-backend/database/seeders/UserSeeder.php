<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        try {
            User::create(
                [
                    'email' => 'admin@gmail.com',
                    'name' => 'سمیع الله',
                    'password' => 'admin',
                    'last_name' => 'حسینی',
                    'role' => 'ادمین',
                ]
            );
        } catch (\Throwable $th) {
            throw $th;
        }
    }
}
