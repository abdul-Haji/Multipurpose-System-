<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BankAccount extends Model
{
    protected $fillable = [
        'bank_name',
        'currency',
        'amount',
        'user_name',
        'account_number',
        'produced_date',
        'expired_date',
        'taken_amount',
        'taken_date',
        'added_amount',
        'added_date',
        'description',
    ];
}
