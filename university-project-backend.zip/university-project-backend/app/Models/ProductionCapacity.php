<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductionCapacity extends Model
{
    protected $fillable = ['product_id', 'amount', 'unit', 'date', 'description'];

    public function product(){
        return $this->belongsTo(Product::class);
    }
}
