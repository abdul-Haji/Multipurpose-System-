<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Stuff extends Model
{
    protected $fillable = [
        'name',
        'father_name',
        'last_name',
        'phone_number',
        'contract_type',
        'contract_start_date',
        'contract_end_date',
        'salary',
        'currency',
        'profile',
        'responsiblity',
        'identity_card_number',
        'full_address',
        'guarantee',
        'description',
    ];

    public function attendances(): HasMany
    {
        return $this->hasMany(StuffAttendance::class);
    }
}
