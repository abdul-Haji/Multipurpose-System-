<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Estate extends Model
{
    protected $fillable = ['estate_type', 'estate_owner', 'price', 'currency', 'date', 'description'];
}
