<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyGood extends Model
{
    protected $fillable = ['name', 'quantity', 'description', 'price_per_tool', 'currency'];
}
