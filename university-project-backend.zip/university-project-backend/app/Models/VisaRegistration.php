<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VisaRegistration extends Model
{
    protected $fillable = [
        'name',
        'last_name',
        'passport_number',
        'phone_number',
        'city',
        'afg_full_address',
        'abroad_full_address',
        'currency',
        'visa_price',
        'airplane_ticket_price',
        'paid_amount',
        'remaining_amount',
        'visa_type',
        'travel_mode',
        'visa_done_status',
        'visa_period',
        'introducer',
        'introducer_phone_number',
        'visa_taken_date',
        'description',
    ];
}
