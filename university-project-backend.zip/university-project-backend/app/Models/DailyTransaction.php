<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DailyTransaction extends Model
{
    protected $fillable = [
        'name',
        'last_name',
        'phone_number',
        'address',
        'transaction_type',
        'amount',
        'currency',
        'date',
        'description'
    ];
}
