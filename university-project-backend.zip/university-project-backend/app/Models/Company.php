<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $fillable = [
        'name',
        'head_name',
        'head_last_name',
        'head_phone_number',
        'assistant_name',
        'assistant_last_name',
        'assistant_phone_number',
        'permission_produced_date',
        'permission_expired_date',
        'permission_produced_place',
        'permission_produced_company',
        'description',
        'paid_amount'
    ];
}
