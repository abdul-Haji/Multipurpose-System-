<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyReport extends Model
{
    protected $fillable = ['company_id', 'report_type', 'activity_type', 'amount', 'date', 'description'];
    public function company(){
        return $this->belongsTo(Company::class);
    }
}
