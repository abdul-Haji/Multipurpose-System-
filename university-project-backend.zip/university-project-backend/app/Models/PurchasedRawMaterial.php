<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchasedRawMaterial extends Model
{
    protected $fillable = [
        'name',
        'quantity',
        'unit',
        'price_per_unit',
        'currency',
        'date',
        'description',
        'bill_number',
        'buyer_name',
        'sealer_name',
        'sealer_phone_number',
        'company_name',
        'price_in_afg',
        'currency_price_in_afg'
    ];
}
