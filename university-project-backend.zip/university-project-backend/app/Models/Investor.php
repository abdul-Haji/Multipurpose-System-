<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Investor extends Model
{
    protected $fillable = [
        'name',
        'last_name',
        'phone_number',
        'address',
        'amount',
        'currency',
        'date',
        'remark',
        'description'
    ];
}
