<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StuffPaymentSalary extends Model
{
    protected $fillable = ['stuff_id', 'paid_amount','remaining_amount', 'paid_date', 'description'];


    public function stuff(){
        return $this->belongsTo(Stuff::class);
    }
}
