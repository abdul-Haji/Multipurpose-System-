<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MyPassword extends Model
{
    protected $fillable = ['account_name', 'phone_number', 'password', 'description'];
}
