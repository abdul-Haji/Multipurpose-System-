<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OfficeWarehouseExpense extends Model
{
    protected $fillable = ['type', 'amount', 'currency', 'date', 'description'];
}
