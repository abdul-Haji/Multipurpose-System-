<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditAndDebet extends Model
{
    protected $table = 'credits_and_debets';

    protected $fillable = [
        'transaction_type',
        'amount',
        'currency',
        'description',
        'name',
        'father_name',
        'phone_number',
        'address',
        'status',
        'payment_reason'
    ];
}
