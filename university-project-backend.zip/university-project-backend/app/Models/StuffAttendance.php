<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StuffAttendance extends Model
{
    protected $fillable = [
        'stuff_id',
        'date',
        'status',
        'description',
    ];

    public function stuff(): BelongsTo
    {
        return $this->belongsTo(Stuff::class);
    }
}
