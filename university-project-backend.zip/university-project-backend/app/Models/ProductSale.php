<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductSale extends Model
{
    protected $fillable = [
        'customer_id',
        'product_id',
        'quantity',
        'unit',
        'currency',
        'price_per_unit',
        'date',
        'description',
        'price_in_afg',
        'currency_price_in_afg',
        'shop_name',
        'paid_amount',
        'remaining_amount',
    ];


    public function customer(){
        return $this->belongsTo(Customer::class);
    }

    public function product(){
        return $this->belongsTo(Product::class);
    }
}
