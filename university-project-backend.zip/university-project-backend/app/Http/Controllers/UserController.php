<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = User::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $path = null;
            if ($request->hasFile('profile')) {
                $path = $request->file('profile')
                    ->store('attachements', 'public');
            }

            $user = User::create([
                'name' => $request->name,
                'last_name' => $request->last_name,
                'profile' => $path,
                'password' => $request->password,
                'role' => $request->role,
            ]);

            return response()->json($user, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $user = User::find($id);
            $fillables = (new User())->getFillable();
            $attributes = $request->only($fillables);
            DB::beginTransaction();
            if ($user) {
                $path = null;

                if ($request->hasFile('profile')) {
                    if ($user->profile && Storage::disk('public')->exists($user->profile)) {
                        Storage::disk('public')->delete($user->profile);
                    }
                    $path = $request->file('profile')->store('attachements', 'public');
                    $attributes['profile'] = $path;
                }
                $user->update($attributes);
            }

            DB::commit();
            return response()->json($user, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = User::find($id);
            if ($data) {
                if ($data->profile && Storage::disk('public')->exists($data->profile)) {
                    Storage::disk('public')->delete($data->profile);
                }
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
