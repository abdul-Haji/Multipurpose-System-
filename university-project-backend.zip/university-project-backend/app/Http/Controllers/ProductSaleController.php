<?php

namespace App\Http\Controllers;

use App\Models\ProductSale;
use Illuminate\Http\Request;

class ProductSaleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = ProductSale::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $query->with('customer:id,name', 'product:id,name');
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new ProductSale())->getFillable();
            $attributes = $request->only($fillable);
            if ($request->currency !== 'افغانی') {
                $attributes['price_in_afg'] =  $request->quantity * $request->price_per_unit * $request->currency_price_in_afg;
            } else {
                $attributes['price_in_afg'] = $request->quantity * $request->price_per_unit;
            }

            $attributes['remaining_amount'] = ($request->quantity * $request->price_per_unit) - $request->paid_amount;
            $res = ProductSale::create($attributes);
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $productSale = ProductSale::findOrFail($id);

            $fillable = $productSale->getFillable();
            $attributes = $request->only($fillable);

            if ($request->currency !== 'افغانی') {
                $attributes['price_in_afg'] =
                    $request->quantity *
                    $request->price_per_unit *
                    $request->currency_price_in_afg;
            } else {
                $attributes['price_in_afg'] =
                    $request->quantity *
                    $request->price_per_unit;
            }

            $attributes['remaining_amount'] =
                ($request->quantity * $request->price_per_unit) -
                $request->paid_amount;
            $productSale->update($attributes);
            return response()->json($productSale, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = ProductSale::find($id);
            if ($data) {
                $data->delete();
            }
            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
