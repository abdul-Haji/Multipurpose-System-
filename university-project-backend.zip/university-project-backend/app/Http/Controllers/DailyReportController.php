<?php

namespace App\Http\Controllers;

use App\Models\BankAccount;
use App\Models\Company;
use App\Models\CompanyGood;
use App\Models\CompanyReport;
use App\Models\Contact;
use App\Models\CreditAndDebet;
use App\Models\Customer;
use App\Models\DailyExpense;
use App\Models\DailyTask;
use App\Models\DailyTransaction;
use App\Models\Estate;
use App\Models\Investor;
use App\Models\MyPassword;
use App\Models\OfficeWarehouseExpense;
use App\Models\PersonalGood;
use App\Models\Product;
use App\Models\ProductionCapacity;
use App\Models\ProductSale;
use App\Models\PurchasedRawMaterial;
use App\Models\Stuff;
use App\Models\StuffPaymentSalary;
use App\Models\User;
use App\Models\VisaRegistration;
use Illuminate\Http\Request;

class DailyReportController extends Controller
{
    public function dailyReport()
    {
        try {

            $data = [
                'bank_accounts' => BankAccount::whereDate('created_at', today())->count(),
                'company' => Company::whereDate('created_at', today())->count(),
                'company_tools' => CompanyGood::whereDate('created_at', today())->count(),
                'company_reports' => CompanyReport::whereDate('created_at', today())->count(),
                'contacts' => Contact::whereDate('created_at', today())->count(),
                'customer' => Customer::whereDate('created_at', today())->count(),
                'daily_expense' => DailyExpense::whereDate('created_at', today())->count(),
                'daily_task' => DailyTask::whereDate('created_at', today())->count(),
                'daily_transaction' => DailyTransaction::whereDate('created_at', today())->count(),
                'estates' => Estate::whereDate('created_at', today())->count(),
                'investors' => Investor::whereDate('created_at', today())->count(),
                'passwords' => MyPassword::whereDate('created_at', today())->count(),
                'office_warehouse_expense' => OfficeWarehouseExpense::whereDate('created_at', today())->count(),
                'personal_good' => PersonalGood::whereDate('created_at', today())->count(),
                'product' => Product::whereDate('created_at', today())->count(),
                'production_capacity' => ProductionCapacity::whereDate('created_at', today())->count(),
                'product_sales' => ProductSale::whereDate('created_at', today())->count(),
                'raw_material' => PurchasedRawMaterial::whereDate('created_at', today())->count(),
                'stuff' => Stuff::whereDate('created_at', today())->count(),
                'stuff_payment' => StuffPaymentSalary::whereDate('created_at', today())->count(),
                'visa_registration' => VisaRegistration::whereDate('created_at', today())->count(),
                'credits_and_debets' => CreditAndDebet::whereDate('created_at', today())->count(),
                'user' => User::whereDate('created_at', today())->count(),
            ];

            return response()->json($data);
        } catch (\Throwable $th) {
            return response()->json(
                $th->getMessage(),
                500
            );
        }
    }



    public function dailyReportList(Request $request)
    {
        $validated = $request->validate([
            'table' => 'required|string'
        ]);

        try {

            $data = $this->viewRecord($validated['table']);

            return response()->json($data, 200);
        } catch (\Throwable $th) {

            return response()->json($th->getMessage(), 500);
        }
    }

    public function viewRecord($table)
    {
        $models = [
            'bank_accounts' => [
                'model' => BankAccount::class,
                'with' => [],
            ],
            'company' => [
                'model' => Company::class,
                'with' => [],
            ],
            'company_tools' => [
                'model' => CompanyGood::class,
                'with' => [],
            ],
            'company_reports' => [
                'model' => CompanyReport::class,
                'with' => ['company:id,name'],
            ],
            'contacts' => [
                'model' => Contact::class,
                'with' => [],
            ],
            'customer' => [
                'model' => Customer::class,
                'with' => [],
            ],
            'daily_expense' => [
                'model' => DailyExpense::class,
                'with' => [],
            ],
            'daily_task' => [
                'model' => DailyTask::class,
                'with' => [],
            ],
            'daily_transaction' => [
                'model' => DailyTransaction::class,
                'with' => [],
            ],
            'estates' => [
                'model' => Estate::class,
                'with' => [],
            ],
            'investors' => [
                'model' => Investor::class,
                'with' => [],
            ],
            'passwords' => [
                'model' => MyPassword::class,
                'with' => [],
            ],
            'office_warehouse_expense' => [
                'model' => OfficeWarehouseExpense::class,
                'with' => [],
            ],
            'personal_good' => [
                'model' => PersonalGood::class,
                'with' => [],
            ],
            'product' => [
                'model' => Product::class,
                'with' => [],
            ],
            'production_capacity' => [
                'model' => ProductionCapacity::class,
                'with' => ['product:id,name'],
            ],
            'product_sales' => [
                'model' => ProductSale::class,
                'with' => ['customer:id,name', 'product:id,name'],
            ],
            'raw_material' => [
                'model' => PurchasedRawMaterial::class,
                'with' => [],
            ],
            'stuff' => [
                'model' => Stuff::class,
                'with' => [],
            ],
            'stuff_payment' => [
                'model' => StuffPaymentSalary::class,
                'with' => ['stuff:id,name'],
            ],
            'visa_registration' => [
                'model' => VisaRegistration::class,
                'with' => [],
            ],
            'credits_and_debets' => [
                'model' => CreditAndDebet::class,
                'with' => [],
            ],
            'user' => [
                'model' => User::class,
                'with' => [],
            ],
        ];

        if (!array_key_exists($table, $models)) {
            return [];
        }

        $config = $models[$table];

        return $config['model']
            ::with($config['with'])
            ->whereDate('created_at', today())
            ->paginate(15);
    }
}
