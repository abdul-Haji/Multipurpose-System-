<?php

namespace App\Http\Controllers;

use App\Models\CreditAndDebet;
use Illuminate\Http\Request;

class CreditAndDebetController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = CreditAndDebet::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new CreditAndDebet())->getFillable();
            $attributes = $request->only($fillable);
            $res = CreditAndDebet::create($attributes);
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $data = CreditAndDebet::findOrFail($id);
            return response()->json($data, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $data = CreditAndDebet::findOrFail($id);
            $fillable = $request->only($data->getFillable());
            $result = $data->update($fillable);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = CreditAndDebet::find($id);
            if ($data) {
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }


    /**
     * Adjust the amount of an existing transaction based on an incoming transaction.
     *
     * If the existing and incoming transaction types are the same, the amounts are
     * added together. If they differ, the incoming amount is subtracted from the
     * existing amount.
     */
    public function adjust(Request $request)
    {
        try {
            $validated = $request->validate([
                'id' => 'required|exists:credits_and_debets,id',
                'transaction_type' => 'required|in:paid,recieved',
                'amount' => 'required|numeric|min:0',
            ]);

            $data = CreditAndDebet::findOrFail($validated['id']);

            $existingAmount = (float) $data->amount;
            $incomingAmount = (float) $validated['amount'];

            if ($data->transaction_type === $validated['transaction_type']) {
                $data->amount = $existingAmount + $incomingAmount;
            } else {
                $data->amount = $existingAmount - $incomingAmount;
            }

            $data->save();

            return response()->json($data, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

      public function changeStatus(Request $request)
    {
        try {
            $data = CreditAndDebet::find($request->id);
            if (! $data) {
                return response()->json('Record not found', 404);
            }
            $data->status = $request->status;
            $data->save();
            return response()->json(true, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
