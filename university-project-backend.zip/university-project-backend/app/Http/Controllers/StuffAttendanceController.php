<?php

namespace App\Http\Controllers;

use App\Models\Stuff;
use App\Models\StuffAttendance;
use Illuminate\Http\Request;

class StuffAttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * Optionally filter by date or by a single staff member.
     */
    public function index(Request $request)
    {
        try {
            $query = StuffAttendance::with('stuff');
            if ($request->date) {
                $query->whereDate('date', $request->date);
            }
            if ($request->stuff_id) {
                $query->where('stuff_id', $request->stuff_id);
            }
            $result = $query->orderByDesc('date')->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a single attendance record.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new StuffAttendance())->getFillable();
            $attributes = $request->only($fillable);
            // one record per staff per day: update if it already exists
            $res = StuffAttendance::updateOrCreate(
                ['stuff_id' => $attributes['stuff_id'] ?? null, 'date' => $attributes['date'] ?? null],
                $attributes
            );
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Report the absent days of all staff members within a date range.
     *
     * If no range is provided it defaults to the last one month.
     * Optional query params: from (YYYY-MM-DD), to (YYYY-MM-DD).
     */
    public function absentReport(Request $request)
    {
        try {
            $to = $request->to ?: now()->toDateString();
            $from = $request->from ?: now()->subMonth()->toDateString();

            $absences = StuffAttendance::with('stuff')
                ->where('status', 'absent')
                ->whereBetween('date', [$from, $to])
                ->orderBy('date')
                ->get()
                ->groupBy('stuff_id');

            $report = Stuff::orderBy('name')->get()->map(function ($stuff) use ($absences) {
                $records = $absences->get($stuff->id, collect());
                return [
                    'stuff_id' => $stuff->id,
                    'name' => $stuff->name,
                    'last_name' => $stuff->last_name,
                    'absent_days' => $records->count(),
                    'dates' => $records->pluck('date')->values(),
                ];
            });

            return response()->json([
                'from' => $from,
                'to' => $to,
                'report' => $report,
            ], 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Take attendance for many staff members at once for a given date.
     *
     * Expects: { date, records: [{ stuff_id, status, description }, ...] }
     */
    public function bulkStore(Request $request)
    {
        try {
            $date = $request->date;
            $records = $request->records ?? [];
            foreach ($records as $record) {
                StuffAttendance::updateOrCreate(
                    ['stuff_id' => $record['stuff_id'] ?? null, 'date' => $date],
                    [
                        'status' => $record['status'] ?? 'present',
                        'description' => $record['description'] ?? null,
                    ]
                );
            }
            return response()->json(true, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $data = StuffAttendance::with('stuff')->findOrFail($id);
            return response()->json($data, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $data = StuffAttendance::findOrFail($id);
            $fillable = $request->only($data->getFillable());
            $result = $data->update($fillable);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = StuffAttendance::find($id);
            if ($data) {
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
