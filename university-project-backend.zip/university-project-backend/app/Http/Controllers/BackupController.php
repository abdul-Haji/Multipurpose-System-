<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class BackupController extends Controller
{
    /**
     * Tables that hold framework/internal state, not business data.
     */
    private array $excluded = [
        'migrations',
        'password_reset_tokens',
        'password_resets',
        'failed_jobs',
        'jobs',
        'job_batches',
        'sessions',
        'cache',
        'cache_locks',
        'personal_access_tokens',
    ];

    /**
     * Retrieve all data from all tables and return it as a downloadable
     * JSON backup file.
     */
    public function backup()
    {
        try {
            $database = DB::connection()->getDatabaseName();
            $backup = [];
            foreach (Schema::getTableListing() as $table) {
                // Laravel 12 may return schema-qualified names ("db.table") for
                // every database on the server. Keep only the current database
                // and strip the prefix.
                if (str_contains($table, '.')) {
                    [$schema, $name] = explode('.', $table, 2);
                    if ($schema !== $database) {
                        continue;
                    }
                    $table = $name;
                }

                if (in_array($table, $this->excluded)) {
                    continue;
                }
                $backup[$table] = DB::table($table)->get();
            }

            $payload = [
                'generated_at' => now()->toDateTimeString(),
                'database' => $database,
                'tables' => $backup,
            ];

            $fileName = 'backup_' . now()->format('Y_m_d_His') . '.json';

            return response()->json($payload, 200, [
                'Content-Disposition' => 'attachment; filename="' . $fileName . '"',
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Restore data from a previously generated JSON backup file.
     *
     * Workflow after a data loss:
     *   1. php artisan migrate   (recreate the empty tables)
     *   2. POST this endpoint with the backup file as `backup_file`
     *
     * Expects a multipart upload with field `backup_file` (the .json file).
     */
    public function restore(Request $request)
    {
        $request->validate([
            'backup_file' => 'required|file|mimes:json,txt',
        ]);

        try {
            $content = file_get_contents($request->file('backup_file')->getRealPath());
            $data = json_decode($content, true);

            if (! is_array($data) || ! isset($data['tables']) || ! is_array($data['tables'])) {
                return response()->json('Invalid backup file format', 422);
            }

            DB::transaction(function () use ($data) {
                // turn off FK checks so insertion order / relations don't block the import
                DB::statement('SET FOREIGN_KEY_CHECKS=0');

                foreach ($data['tables'] as $table => $rows) {
                    if (in_array($table, $this->excluded) || ! Schema::hasTable($table)) {
                        continue;
                    }

                    // make the import idempotent: clear the table first.
                    // delete() (not truncate()) so it stays inside the transaction
                    // and rolls back if any later insert fails.
                    DB::table($table)->delete();

                    foreach (array_chunk($rows, 500) as $chunk) {
                        if (! empty($chunk)) {
                            DB::table($table)->insert($chunk);
                        }
                    }
                }

                DB::statement('SET FOREIGN_KEY_CHECKS=1');
            });

            return response()->json('Backup restored successfully', 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
