<?php

namespace App\Http\Controllers;

use App\Models\PurchasedRawMaterial;
use Illuminate\Http\Request;

class PurchasedRawMaterialController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = PurchasedRawMaterial::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new PurchasedRawMaterial())->getFillable();
            $attributes = $request->only($fillable);
            if ($request->currency !== 'افغانی') {
                $attributes['price_in_afg'] = ($request->quantity * $request->price_per_unit) * $request->currency_price_in_afg;
            } else {
                $attributes['price_in_afg'] = ($request->quantity * $request->price_per_unit);
            }
            $res = PurchasedRawMaterial::create($attributes);
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $purchasedRawMaterial = PurchasedRawMaterial::findOrFail($id);
            $fillable = $purchasedRawMaterial->getFillable();
            $attributes = $request->only($fillable);
            if ($request->currency !== 'افغانی') {
                $attributes['price_in_afg'] = ($request->quantity * $request->price_per_unit) * $request->currency_price_in_afg;
            } else {
                $attributes['price_in_afg'] = ($request->quantity * $request->price_per_unit);
            }
            $purchasedRawMaterial->update($attributes);
            return response()->json($purchasedRawMaterial, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = PurchasedRawMaterial::find($id);
            if ($data) {
                $data->delete();
            }
            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    public function rawMaterialsList()
    {
        try {
            $data = PurchasedRawMaterial::select('id', 'name', 'quantity', 'unit')->get();
            return response()->json($data, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    public function pick(Request $request)
    {
        $validated = $request->validate([
            'id' => 'required|exists:purchased_raw_materials,id',
            'amount' => 'required',
        ]);

        try {
            $material = PurchasedRawMaterial::findOrFail($validated['id']);
            if ($material->quantity < $validated['amount']) {
                return response()->json([
                    'message' => 'مقدار انتخاب شده بیشتر از مقدار موجود در انبار است.',
                ], 400);
            }
            $material->decrement('quantity', $validated['amount']);
            return response()->json($material, 200);
        } catch (\Throwable $th) {
            return response()->json([
                'success' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
}
