<?php

namespace App\Http\Controllers;

use App\Models\StuffPaymentSalary;
use Illuminate\Http\Request;

class StuffPaymentSalaryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = StuffPaymentSalary::query();
            $query->with('stuff:id,name');
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
         try {
            $fillable = (new StuffPaymentSalary())->getFillable();
            $attributes = $request->only($fillable);
            $result = StuffPaymentSalary::create($attributes);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $data = StuffPaymentSalary::findOrFail($id);
            $fillable = $request->only($data->getFillable());
            $result = $data->update($fillable);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
         try {
            $stuff_payment = StuffPaymentSalary::find($id);
            if ($stuff_payment) {
                $stuff_payment->delete();
            }
            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
