<?php

namespace App\Http\Controllers;

use App\Models\CompanyGood;
use Illuminate\Http\Request;

class CompanyGoodController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = CompanyGood::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new CompanyGood())->getFillable();
            $attributes = $request->only($fillable);
            $res = CompanyGood::create($attributes);
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $companyGood = CompanyGood::findOrFail($id);
            $data = $request->only($companyGood->getFillable());
            $companyGood->update($data);
            return response()->json($companyGood, 200);
        } catch (\Throwable $th) {
            return response()->json([
                'message' => $th->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = CompanyGood::find($id);
            if ($data) {
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
