<?php

namespace App\Http\Controllers;

use App\Models\BankAccount;
use Illuminate\Http\Request;

class BankAccountController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = BankAccount::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new BankAccount())->getFillable();
            $attributes = $request->only($fillable);
            $res = BankAccount::create($attributes);
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $bankAccounts = BankAccount::findOrFail($id);
            $fillable = $request->only($bankAccounts->getFillable());
            $result = $bankAccounts->update($fillable);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = BankAccount::find($id);
            if ($data) {
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }


    public function transactions(Request $request)
    {
        try {
            $bankAccounts = BankAccount::find($request->id);
            if ($request->type == 'add') {
                $bankAccounts->update(
                    [
                        'amount' => $bankAccounts->amount + $request->amount,
                        'added_amount' => $request->amount,
                        'added_date' => $request->date
                    ]
                );
            } else {
                $bankAccounts->update(
                    [
                        'amount' => $bankAccounts->amount - $request->amount,
                        'taken_amount' => $request->amount,
                        'taken_date' => $request->date
                    ]
                );
            }
            return response()->json($bankAccounts, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
