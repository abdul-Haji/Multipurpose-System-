<?php

namespace App\Http\Controllers;

use App\Models\VisaRegistration;
use Illuminate\Http\Request;

class VisaRegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = VisaRegistration::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new VisaRegistration())->getFillable();
            $attributes = $request->only($fillable);
            $attributes['remaining_amount'] = ((float) ($attributes['visa_price'] ?? 0)
                + (float) ($attributes['airplane_ticket_price'] ?? 0))
                - (float) ($attributes['paid_amount'] ?? 0);
            $res = VisaRegistration::create($attributes);
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $data = VisaRegistration::findOrFail($id);
            $fillable = $request->only($data->getFillable());
            $visa_price = (float) ($fillable['visa_price'] ?? $data->visa_price);
            $airplane_ticket_price = (float) ($fillable['airplane_ticket_price'] ?? $data->airplane_ticket_price);
            $paid_amount = (float) ($fillable['paid_amount'] ?? $data->paid_amount);
            $fillable['remaining_amount'] = ($visa_price + $airplane_ticket_price) - $paid_amount;
            $result = $data->update($fillable);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = VisaRegistration::find($id);
            if ($data) {
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    public function changeStatus(Request $request)
    {
        try {
            $data = VisaRegistration::find($request->id);
            if (! $data) {
                return response()->json('Record not found', 404);
            }
            $data->visa_done_status = $request->visa_done_status;
            $data->save();
            return response()->json(true, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
