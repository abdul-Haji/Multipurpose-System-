<?php

namespace App\Http\Controllers;

use App\Models\PersonalGood;
use Illuminate\Http\Request;

class PersonalGoodController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = PersonalGood::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $fillable = (new PersonalGood())->getFillable();
            $attributes = $request->only($fillable);
            $res = PersonalGood::create($attributes);
            return response()->json($res, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $good = PersonalGood::findOrFail($id);
            $fillable = $request->only($good->getFillable());
            $result = $good->update($fillable);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = PersonalGood::find($id);
            if ($data) {
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
