<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'password' => 'required|string',
            ]);

            $user = User::where('email', $request->email)->first();

            if (!$user || !Hash::check($request->password, $user->password)) {
                return response()->json([
                    'message' => 'User not found'
                ], 401);
            }

            $token = $user->createToken($user->name . '-AuthToken')->plainTextToken;
            return response()->json([
                'token' => $token,
                'user' => $user,
            ], 200);
        } catch (\Throwable $th) {

            return response()->json([
                'error' => $th->getMessage()
            ], 500);
        }
    }


    public function logout(Request $request)
    {
        try {
            $user = User::where('id', $request->user()->id)->first();
            if ($user) {
                $user->tokens()->delete();
            }
            return response()->json(true, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
