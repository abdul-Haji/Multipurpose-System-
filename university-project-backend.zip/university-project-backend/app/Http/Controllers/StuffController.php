<?php

namespace App\Http\Controllers;

use App\Models\Stuff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class StuffController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->search;
            $search_by = $request->searchBy;
            $query = Stuff::query();
            if ($search) {
                $query->where($search_by, 'LIKE', "%$search%");
            }
            $result = $query->paginate(15);
            return response()->json($result, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $path = null;
            if ($request->hasFile('profile')) {
                $path = $request->file('profile')
                    ->store('attachements', 'public');
            }

            $fillabes = (new Stuff())->getFillable();
            $attributes = $request->only($fillabes);
            $attributes['profile'] = $path;
            $stuff = Stuff::create($attributes);
            return response()->json($stuff, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $stuff = Stuff::find($id);
            $fillabes = (new Stuff())->getFillable();
            $attributes = $request->only($fillabes);
            DB::beginTransaction();
            if ($stuff) {
                $path = null;

                if ($request->hasFile('profile')) {
                    if ($stuff->profile && Storage::disk('public')->exists($stuff->profile)) {
                        Storage::disk('public')->delete($stuff->profile);
                    }
                    $path = $request->file('profile')->store('attachements', 'public');
                    $attributes['profile'] = $path;
                }
                $stuff->update($attributes);
            }

            DB::commit();
            return response()->json($stuff, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = Stuff::find($id);
            if ($data) {
                if ($data->profile && Storage::disk('public')->exists($data->profile)) {
                    Storage::disk('public')->delete($data->profile);
                }
                $data->delete();
            }

            return response()->json(true, 206);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }

    public function suffsList(Request $request){
        try {
            $stuff = Stuff::get();
            return response()->json($stuff, 200);
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), 500);
        }
    }
}
