<template>
  <v-card
    class="mt-5"
    elevation="0"
    border
    style="position: relative"
  >
    <div
      v-if="props.loading"
      style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; z-index: 10"
    >
      <v-progress-circular indeterminate />
    </div>
    <v-table
      height="600px"
      fixed-header
    >
      <thead>
        <tr>
          <th
            v-for="header in props.headers"
            :key="header.key"
            style="font-size: 13px !important; text-wrap: nowrap !important"
          >
            {{ header.title }}
          </th>
        </tr>
      </thead>
      <tbody v-if="!loading">
        <tr
          v-for="record in props.tableRecords"
          :key="record.id"
        >
          <td
            v-for="header in props.headers"
            :key="header.key"
            style="text-wrap: nowrap !important; white-space: nowrap !important; width: 1%"
          >
            <slot
              :name="header.key"
              :record="record"
              :th="props.headers"
            >
              {{ record[header.key] }}
            </slot>
          </td>
        </tr>
      </tbody>
    </v-table>
    <v-divider></v-divider>
    <v-card-actions class="pt-2">
      <v-pagination
        v-on:update:model-value="onPageChange"
        v-model="page"
        :length="props.totalPages"
        :total-visible="7"
      ></v-pagination>
    </v-card-actions>
  </v-card>
</template>
<script setup>
import { ref } from 'vue'

const emit = defineEmits(['onPaginate'])
const props = defineProps({
  headers: {
    type: Array,
    required: true,
  },

  tableRecords: {
    type: Array,
    default: () => [],
  },

  loading: {
    type: Boolean,
    default: false,
  },
  totalPages: {
    type: Number,
    default: 1,
  },
})

const page = ref(1)

const onPageChange = value => {
  emit('onPaginate', value)
}
</script>
